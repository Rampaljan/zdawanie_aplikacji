﻿using System.Diagnostics;
//dodatkowy nuget
using Microsoft.Management.Infrastructure;


namespace calki
{
    public class ModelCalki
    {
        public string Nazwa { get; set; }
        //tutaj wsadzamy jakąkolwiek funckje chcemy, przyjmuje x jako double i wynik zwraca jako double
        public Func<double, double> Funkcja { get; set; }
        public double Dolna { get; set; }
        public double Gorna { get; set; }
        //rozdzielczość (co ile iksów zaczyna sie kolejny prostokąt)
        public double dx { get; set; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            var wyniki = new List<string>();

            var calki = new[]
            {
                new ModelCalki
                {
                    Nazwa = "{0}^{10} (3x^3 - 2x + 5)",
                    Funkcja = x => 3 * x * x * x - 2 * x + 5,
                    Dolna = 0,
                    Gorna = 10,
                    dx = 0.001
                },
                new ModelCalki
                {
                    Nazwa = "{0}^{20} ln(x + 1)",
                    Funkcja = x => Math.Log(x + 1),
                    Dolna = 0,
                    Gorna = 20,
                    dx = 0.001
                },
                new ModelCalki
                {
                    Nazwa = "{0}^{200,000} sin(x) * cos(x) * sqrt{x}",
                    Funkcja = x => Math.Sin(x) * Math.Cos(x) * Math.Sqrt(x),
                    Dolna = 0,
                    Gorna = 200000,
                    dx = 0.001
                }
            };

            //https://www.algorytm.org/procedury-numeryczne/calkowanie-numeryczne-metoda-prostokatow/metoda-prostokatow-cs.html
            void sekwencyjnie(ModelCalki calka)
            {
                var timer = new Stopwatch();
                timer.Start();

                double suma = 0;
                for (double x = calka.Dolna; x < calka.Gorna; x += calka.dx)
                {
                    double wysokosc = (calka.Funkcja(x) + calka.Funkcja(x + calka.dx)) / 2.0;
                    suma += wysokosc * calka.dx;
                }

                timer.Stop();

                Console.WriteLine("Całka: " + calka.Nazwa);
                Console.WriteLine("Metoda: sekwencyjnie");
                Console.WriteLine("Wynik: " + suma);
                Console.WriteLine("Czas wykonania w ms: " + timer.Elapsed.TotalMilliseconds);
                Console.WriteLine("");

                wyniki.Add("Całka: " + calka.Nazwa);
                wyniki.Add("Metoda: sekwencyjnie");
                wyniki.Add("Wynik: " + suma);
                wyniki.Add("Czas wykonania w ms: " + timer.Elapsed.TotalMilliseconds);
                wyniki.Add("");

                return;
            }

            for (int i = 0; i < calki.Length; i++)
            {
                sekwencyjnie(calki[i]);
            }


            void rownolegle(ModelCalki calka, int stopien)
            {
                var timer = new Stopwatch();
                timer.Start();

                long liczbaProstokatow = (long)((calka.Gorna - calka.Dolna) / calka.dx);
                double sumaGlobalna = 0;
                object blokada = new object();

                Parallel.For(
                    0L,                    //od
                    liczbaProstokatow,     // do
                    new ParallelOptions { MaxDegreeOfParallelism = stopien }, //definiujemy ile chcemy dać mu wątków

                    () => 0.0,             // sumalokalna kazdego wątku to 0

                    //tą lambde ponizej on sobie przypisuje do kazdego z wątków i iteruje po tych prostokątach po i tak jak uważa
                    //sami nie deklarujemy ile konkretnie musi tych prostokątów wyliczyć jakbysmy to robili w threads, bo parallel.for sam to ustala,
                    //oddając trochę pracy wątkowi który juz na przyklad skonczyl, a zabierając temu który ma dużo roboty

                    (i, stan, sumaLokalna) => //stan musi być, wsm to nic nie robi, moze byc uzyty jakby trzeba bylo przerwac petle w danym watku np stan.Break()
                    {
                        double x = calka.Dolna + i * calka.dx;
                        double wysokosc = (calka.Funkcja(x) + calka.Funkcja(x + calka.dx)) / 2.0;
                        return sumaLokalna + wysokosc * calka.dx;  // zwracamy nową sumę lokalną
                    },

                    sumaLokalna =>         // jak wątek sie konczy to zwraca sume lokalna do globalnej
                    {
                        lock (blokada) //musi byc lock bo jak dwa watki skoncza w tym samym czasie i pobiorą sumeglobalną i beda chcialy do niej dodac to jeden wynikm moze nadpisac drugi
                        {
                            sumaGlobalna += sumaLokalna;
                        }
                    }
                );

                timer.Stop();

                Console.WriteLine("Całka: " + calka.Nazwa);
                Console.WriteLine("Metoda: Parallel.For, stopień: " + stopien);
                Console.WriteLine("Wynik: " + sumaGlobalna);
                Console.WriteLine("Czas wykonania w ms: " + timer.Elapsed.TotalMilliseconds);
                Console.WriteLine("");

                wyniki.Add("Całka: " + calka.Nazwa);
                wyniki.Add("Metoda: Parallel.For, stopień: " + stopien);
                wyniki.Add("Wynik: " + sumaGlobalna);
                wyniki.Add("Czas wykonania w ms: " + timer.Elapsed.TotalMilliseconds);
                wyniki.Add("");
            }

            foreach (var calka in calki)
            {
                foreach (int stopien in new[] { 2, 4, 8 })
                {
                    rownolegle(calka, stopien);
                }
            }

            // readme każe zeby bylo odniesienie do procesora no to będzie
            var session = CimSession.Create(null);
            var cpu = session.QueryInstances("root/cimv2", "WQL", "SELECT Name FROM Win32_Processor").First();
            string procek = cpu.CimInstanceProperties["Name"].Value.ToString();

            Console.WriteLine("Procesor: " + procek);
            wyniki.Add("Procesor: " + procek);

            string sciezka = Path.GetFullPath("wyniki.md");
            Console.WriteLine("Zapisano do: " + sciezka);
            File.WriteAllLines(sciezka, wyniki);
        }
    }
}
